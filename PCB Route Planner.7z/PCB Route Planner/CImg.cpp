#include "CImg.hpp"
#include "jpeglib.hpp"
using namespace cimg_library;

int main()
{
	CImg<unsigned char> image("Resistor.jpg");
	CImgDisplay main_disp(image, "Placing Resistor");
}