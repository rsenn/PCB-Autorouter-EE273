/*/#include <iostream>
#include "COMPONENTS.CPP"
using namespace std;

int main()
{
	Component c;
	int x, y, z;

	cout << "Enter your chosen coordinates: " << endl;
	cout << "x = ";
	cin >> x;
	cout << "y = ";
	cin >> y;
	cout << "z = ";
	cin >> z;

	cout << c.Coordinates[x][y][z];

	system("pause>nul");

}/*/