#ifndef Path_hpp
#define Path_Hpp
#include "Node.hpp"

vector<node> findPath(node, node, node[PCBLength][PCBWidth][PCBLayers]);

float findLength(vector<node>);
#endif