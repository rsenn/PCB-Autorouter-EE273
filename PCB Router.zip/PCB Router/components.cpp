#include "components.h"

component::component() {
	numberOfPins = 1;
	for (int i = 0; i < numberOfPins; i++) {
		coordinates.resize(numberOfPins);
	}
}

void component::setNumberOfPins(int num) {
	num = numberOfPins;
}

int component::getNumberOfPins() {
	return numberOfPins;
}

void component::setName(int iter, int val) {
	name[iter] = val;
}

int component::getName(int iter) {
	return name[iter];
}

void component::setCoordinate(int iter, coord coordinate) {
	coordinates[iter] = coordinate;
}

coord component::getCoordinate(int iter) {
	return coordinates[iter];
}

resistor::resistor() {
	numberOfPins = 2;
}

void resistor::place(coord coordinate, CImg<unsigned int> PCB) {
	int x = coordinate.get('x');
	int y = coordinate.get('y');
	int z = coordinate.get('z');

	PCB.draw_rectangle();
	
}

capacitor::capacitor() {
	numberOfPins = 2;
}

void capacitor::place(coord coordinate, CImg<unsigned int> PCB) {

}

transistor::transistor() {
	numberOfPins = 3;
}

void transistor::place(coord coordinate, CImg<unsigned int> PCB) {

}

LED::LED() {
	numberOfPins = 2;
}

void LED::place(coord coordinate, CImg<unsigned int> PCB) {

}

IC::IC() {
	numberOfPins = 8;
}

void IC::place(coord coordinate, CImg<unsigned int>) {
}