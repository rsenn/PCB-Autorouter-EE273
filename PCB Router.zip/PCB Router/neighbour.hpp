#ifndef Neighbour_hpp
#define Neighbour_hpp

#include <vector>
#include "Node.hpp"

vector<node>findNeighbours(int, int, int); // Find neighbours of coordinate
// Arguments = x, y, z coordinates of point

#endif // !neighbour_h