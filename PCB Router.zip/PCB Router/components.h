#include "Node.h"
#include "CImg.h"
using namespace cimg_library;

class component {
protected:
	int numberOfPins;
	int *name = new int[numberOfPins];
	vector<coord> coordinates;

public:
	component();
	void setNumberOfPins(int);
	int getNumberOfPins();

	void setName(int, int);
	int getName(int);

	void setCoordinate(int, coord);
	coord getCoordinate(int);
};

class resistor : protected component {
public:
	resistor();
	void place(coord, CImg<unsigned int>);
};

class capacitor : protected component {
public:
	capacitor();
	void place(coord, CImg<unsigned int>);
};

class transistor : protected component {
public:
	transistor();
	void place(coord, CImg<unsigned int>);
};

class LED : protected component {
public:
	LED();
	void place(coord, CImg<unsigned int>);
};

class IC : protected component {
public:
	IC();
	void place(coord, CImg<unsigned int>);
};