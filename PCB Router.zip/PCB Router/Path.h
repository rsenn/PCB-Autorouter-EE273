#ifndef Path_h
#define Path_H
#include "Node.h"

vector<node> findPath(node, node, node[PCBLength][PCBWidth][PCBLayers]);

float findLength(vector<node>);
#endif