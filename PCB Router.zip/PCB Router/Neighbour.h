#ifndef Neighbour_h
#define Neighbour_h

#include <vector>
#include "Node.h"

vector<node>findNeighbours(int, int, int); // Find neighbours of coordinate
// Arguments = x, y, z coordinates of point

bool testPlace(node, int, node[PCBLength][PCBWidth][PCBLayers], vector<node>);

#endif // !neighbour_h
